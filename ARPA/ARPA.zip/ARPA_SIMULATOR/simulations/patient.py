'''
Type 1 diabetic patient generator for ARPA project
Last Updated 2.28.2022 by Landon Flemming

The generated file will be in a CSV format, meant to be used as data for a ML model
'''
#imports
import csv
import random

#global variables
exercising_t_or_f = False
sleeping_t_or_f = False
is_eating_b = False
is_eating_l = False
is_eating_d = False
current_state = False
carb_intake = 0
counter = 0
meal_last_val = random.randint(80, 130)
slope = 0
#state number identifiers - 
#1 - exercising
#2 - sleeping
#3 - breakfast
#4 - lunch
#5 - dinner
#6 - basal


#inputs for the variables
nom_hb =100 #float(input("nominal daytime heartrate: "))
#usually 10g of carbohydrates increase blood gl lvl by 36-54 mg/dL
carb_to_gl_ratio =36 #float(input("how many mg/dL does 10g of carbs increase blood glucose by?: "))
#usually around 80 mg/dL
target_gl_lowend =80 #float(input("low end of target blood glucose level: "))
#usually around 130 mg/dL, but will spike to ~180ish after eating
target_gl_highend =130#float(input("high end of target blood glucose level: "))

sleep_start =22 #float(input("usual bed time: "))
sleep_end =6 #float(input("usual wake up time: "))
sleep_fudge_fact =15 #float(input("average drift from target start and end sleep times: "))
sleep_min_hb =60 #float(input("minimum heart rate of patient while they sleep: "))

exercise = input("does this patient exercise regularly? [y/n]: ")
if exercise == 'y':
    exercise_start = float(input("usual exercise start time: "))
    exercise_end = float(input("usual exercise end time: "))
    exercise_fudge_fact = float(input("average drift from target exercise start and end times(input minutes(15, 30, 45, 60)): "))
    exercise_max_hb = float(input("maximum exercising heartrate: "))
    exercise_rest_day = int(input("what days does this patient not exercise?(1-monday, 2-tuesday, 3-wednesday, etc): "))
    
else: 
    pass

#carb intake should be between 30-45g
breakfast_time =9 #float(input("usual start of breakfast: "))
meal_min_carb_in_b =30 #float(input("minimum carb consumption during this meal: "))
meal_max_carb_in_b =45 #float(input("maximum carb consumption during this meal: "))
#carb intake should be between 45-60g
lunch_time =12 #float(input("usual lunch start time: "))
meal_min_carb_in_l =40 #float(input("minimum carb consumption during this meal: "))
meal_max_carb_in_l =60#float(input("maximum carb consumption during this meal: "))
#carb intake should be between 45-60g
dinner_time =17 #float(input("usual dinner start time: "))
meal_min_carb_in_d =40 #float(input("minimum carb consumption during this meal: "))
meal_max_carb_in_d =60 #float(input("maximum carb consumption during this meal: "))


#glucose calculation function
def meal_gl_lvl(time, meal_min_carb_in, meal_max_carb_in, meal_start, state):
    global current_state
    global carb_intake
    global meal_last_val
    global counter
    max_gl_lvl = 180 #180mg/dL
    if counter >= 4:
        current_state = False
        counter = 0
    else:
        pass

    if meal_max_carb_in !=None and meal_min_carb_in !=None and state == False and current_state == False:
        carb_intake = random.randint(meal_min_carb_in, meal_max_carb_in)
        current_state = True
        gl_lvl = -carb_intake*(time-meal_start)*(time-(meal_start+2))+80
        counter = counter + 1
        meal_last_val = gl_lvl
        return gl_lvl
    elif current_state == True:
        gl_lvl = -carb_intake*(time-meal_start)*(time-(meal_start+2))+80
        counter = counter + 1
        meal_last_val = gl_lvl
        return gl_lvl
    else:
        pass

def glucose_lvl(time, target_gl_lowend, target_gl_highend, state):
    global meal_last_val
    try:
        if sleeping_t_or_f == False:
            gl_lvl = random.randint(target_gl_lowend, round(meal_last_val))
            return gl_lvl
        elif sleeping_t_or_f == True:
            gl_lvl = random.randint(target_gl_lowend, target_gl_lowend+10)
            return gl_lvl
    except:
        pass
    





#functions for different states
def exercising(time, exercise_start, exercise_end, exercise_fudge_fact, exercise_max_hb, day_of_the_week, exercise_rest_day, error):
    global exercising_t_or_f
    exercise_fudge_fact = exercise_fudge_fact/60 

    #if error value is greater than 2, the "fudge factor" is implemented, otherwise it is ignored
    if error > 2:
        start_error = exercise_fudge_fact
        end_error = exercise_fudge_fact
    else:
        start_error = 0
        end_error = 0

    if exercising_t_or_f == False and day_of_the_week != exercise_rest_day:
        if (exercise_start + start_error) == time:
            hb = random.randint(exercise_max_hb-50, exercise_max_hb)
            gl_lvl = random.randint(70, 100)
            exercising_t_or_f = True
            return hb, gl_lvl, "exercising"
        else: pass

    if exercising_t_or_f == True:
        if (exercise_end + end_error) <= time:
            exercising_t_or_f = False
        else: 
            hb = random.randint(exercise_max_hb-50, exercise_max_hb)
            gl_lvl = random.randint(70, 100)
            exercising_t_or_f = True
            return hb, gl_lvl, "exercising"

def sleeping(time, sleep_start, sleep_end, sleep_fudge_fact, day_of_the_week, sleep_min_hb, error):
    global sleeping_t_or_f
    sleep_fudge_fact = sleep_fudge_fact/60

    #if error value is greater than 2, the "fudge factor" is implemented, otherwise it is ignored
    if error > 2:
        start_error = sleep_fudge_fact
        end_error = sleep_fudge_fact
    else:
        start_error = 0
        end_error = 0

    if sleeping_t_or_f == False:
        if (sleep_start + sleep_fudge_fact) == time:
            hb = random.randint(sleep_min_hb, sleep_min_hb+20)
            gl_lvl = random.randint(70, 100)
            sleeping_t_or_f = True
            return hb, gl_lvl, 0

    if sleeping_t_or_f == True:
        if sleep_end >= time:
            if sleep_end == time:
                sleeping_t_or_f = False
            else: 
                hb = random.randint(sleep_min_hb, sleep_min_hb+20)
                gl_lvl = random.randint(70, 100)
                sleeping_t_or_f = True
                return hb, gl_lvl, 0
        else: 
            hb = random.randint(sleep_min_hb, sleep_min_hb+20)
            gl_lvl = random.randint(70, 100)
            sleeping_t_or_f = True
            return hb, gl_lvl, 0

def breakfast(time, breakfast_time, day_of_the_week, nom_hb, error):
    global is_eating_b
    if is_eating_b == False:
        if breakfast_time == time:
            hb = random.randint(nom_hb-10, nom_hb+20)
            gl_lvl = meal_gl_lvl(time, meal_min_carb_in_b, meal_max_carb_in_b, breakfast_time, is_eating_b)
            is_eating_b = True
            return hb, round(gl_lvl), 1

    if is_eating_b == True:
        if (breakfast_time + 1.0) == time:
            is_eating_b = False
        else:
            hb = random.randint(nom_hb-10, nom_hb+20)
            gl_lvl = meal_gl_lvl(time, meal_min_carb_in_b, meal_max_carb_in_b, breakfast_time, is_eating_b)
            is_eating_b = True
            return hb, round(gl_lvl), 1

def lunch(time, lunch_time, day_of_the_week, nom_hb, error):
    global is_eating_l
    if is_eating_l == False:
        if lunch_time == time:
            hb = random.randint(nom_hb-10, nom_hb+20)
            gl_lvl = meal_gl_lvl(time, meal_min_carb_in_l, meal_max_carb_in_l, lunch_time, is_eating_l)
            is_eating_l = True
            return hb, round(gl_lvl), 1

    if is_eating_l == True:
        if (lunch_time + 1.0) == time:
            is_eating_l = False
        else:
            hb = random.randint(nom_hb-10, nom_hb+20)
            gl_lvl = meal_gl_lvl(time, meal_min_carb_in_l, meal_max_carb_in_l, lunch_time, is_eating_l)
            is_eating_l = True
            return hb, round(gl_lvl), 1

def dinner(time, dinner_time, day_of_the_week, nom_hb, error):
    global is_eating_d
    if is_eating_d == False:
        if dinner_time == time:
            hb = random.randint(nom_hb-10, nom_hb+20)
            gl_lvl = meal_gl_lvl(time, meal_min_carb_in_d, meal_max_carb_in_l, dinner_time, is_eating_d)
            is_eating_d = True
            return hb, round(gl_lvl), 1

    if is_eating_d == True:
        if (dinner_time + 1.0) == time:
            is_eating_d = False
        else:
            hb = random.randint(nom_hb-10, nom_hb+20)
            gl_lvl = meal_gl_lvl(time, meal_min_carb_in_d, meal_max_carb_in_l, dinner_time, is_eating_d)
            is_eating_d = True
            return hb, round(gl_lvl), 1

def basal(time, nom_hb, target_gl_lowend, target_gl_highend, day_of_the_week, error):
    type = 6
    gl_lvl = glucose_lvl(time, target_gl_lowend, target_gl_highend, state=False)
    hb = random.randint(nom_hb-10, nom_hb+20)
    return hb, gl_lvl, 0


#setup for data generation and randomization
error = random.randint(0, 4)
day_of_the_week = 1 # 1 is for monday, 2 is for tuesday, etc
week_of_the_month = 1 # 1 is the first week, 2 is the second, etc
output = open("output.csv", "a+")
writer = csv.writer(output)


#loop to generate 96 data points a day, 7 days a week, 4 weeks a month
for w in range(1, 5): #range(1,5) because there are ~4 weeks in a month
    for d in range(1, 8):
        for point in range(1, 97):
            #time counter to keep track of the simulated time of day
            time = 0 + ((point*.25))
            if exercise == 'y':
                exercise_period = exercising(time, exercise_start, exercise_end, exercise_fudge_fact, exercise_max_hb, day_of_the_week, exercise_rest_day, error)
                sleeping_period = sleeping(time, sleep_start, sleep_end, sleep_fudge_fact, day_of_the_week, sleep_min_hb, error)
                breakfast_period = breakfast(time, breakfast_time, day_of_the_week, nom_hb, error)
                lunch_period = lunch(time, lunch_time, day_of_the_week, nom_hb, error)
                dinner_period = dinner(time, dinner_time, day_of_the_week, nom_hb, error)
                basal_period = basal(time, nom_hb, target_gl_lowend, target_gl_highend, day_of_the_week, error)

                if sleeping_period != None:
                    output_line = [time, sleeping_period, week_of_the_month, day_of_the_week]
                    writer.writerow(output_line)
                elif breakfast_period != None:
                    output_line = [time, breakfast_period, week_of_the_month, day_of_the_week]
                    writer.writerow(output_line)
                elif lunch_period != None:
                    output_line = [time, lunch_period, week_of_the_month, day_of_the_week]
                    writer.writerow(output_line)
                elif dinner_period != None:
                    output_line = [time, dinner_period, week_of_the_month, day_of_the_week]
                    writer.writerow(output_line)
                elif exercise_period != None:
                    output_line = [time, exercise_period, week_of_the_month, day_of_the_week]
                    writer.writerow(output_line)
                elif sleeping_period == None and breakfast_period == None and lunch_period == None and dinner_period == None and exercise_period == None:
                    output_line = [time, basal_period, week_of_the_month, day_of_the_week]
                    writer.writerow(output_line)
                else: pass
            else:
                sleeping_period = sleeping(time, sleep_start, sleep_end, sleep_fudge_fact, day_of_the_week, sleep_min_hb, error)
                breakfast_period = breakfast(time, breakfast_time, day_of_the_week, nom_hb, error)
                lunch_period = lunch(time, lunch_time, day_of_the_week, nom_hb, error)
                dinner_period = dinner(time, dinner_time, day_of_the_week, nom_hb, error)
                basal_period = basal(time, nom_hb, target_gl_lowend, target_gl_highend, day_of_the_week, error)

                if sleeping_period != None:
                    output_line = [time, day_of_the_week, sleeping_period[0], sleeping_period[1], sleeping_period[2]]
                    writer.writerow(output_line)
                elif breakfast_period != None:
                    output_line = [time, day_of_the_week, breakfast_period[0], breakfast_period[1], breakfast_period[2]]
                    writer.writerow(output_line)
                elif lunch_period != None:
                    output_line = [time, day_of_the_week, lunch_period[0], lunch_period[1], lunch_period[2]]
                    writer.writerow(output_line)
                elif dinner_period != None:
                    output_line = [time, day_of_the_week, dinner_period[0], dinner_period[1], dinner_period[2]]
                    writer.writerow(output_line)
                elif sleeping_period == None and breakfast_period == None and lunch_period == None and dinner_period == None: 
                    output_line = [time, day_of_the_week, basal_period[0], basal_period[1], basal_period[2]]
                    writer.writerow(output_line)
                else: pass


        error = random.randint(0, 4)

        if day_of_the_week == 7:
            day_of_the_week = 1
        else:
            day_of_the_week = day_of_the_week + 1
    week_of_the_month = week_of_the_month + 1

#closes the data file
output.close()