#       ___           ___           ___           ___     
#      /\  \         /\  \         /\  \         /\  \    
#     /::\  \       /::\  \       /::\  \       /::\  \   
#    /:/\:\  \     /:/\:\  \     /:/\:\  \     /:/\:\  \  
#   /::\~\:\  \   /::\~\:\  \   /::\~\:\  \   /::\~\:\  \ 
#  /:/\:\ \:\__\ /:/\:\ \:\__\ /:/\:\ \:\__\ /:/\:\ \:\__\
#  \/__\:\/:/  / \/_|::\/:/  / \/__\:\/:/  / \/__\:\/:/  /
#       \::/  /     |:|::/  /       \::/  /       \::/  / 
#       /:/  /      |:|\/__/         \/__/        /:/  /  
#      /:/  /       |:|  |                       /:/  /   
#      \/__/         \|__|                       \/__/    

'''
Welcome to the information command module. To add commands, uses the below code as a structure

def command_name(self, other_needed_variables):
        num_of_rows = 1 <-number of outputed rows
        calc = 1+2 <- write the code for the command here
        etc.....   <-

        return calc, num_of_rows <-return command values, as well as num_of_rows


Make sure to add the command to the dictionary labeled 'commands' in the def recog_command in the class Command, in the below format:
{'command': self.command()}

Also, add the command to the below dictionary labeled all_commands, formated in the same way as the other commands:
'''

all_commands = {'help':'help', 'current_time':'current_time'}
num_of_term_rows = 30

####imported libraries
from datetime import datetime
import re
from tkinter import filedialog
import os
import sys


class Info_Command:
    def recog_command(self, command, counter):
        
        self.command = command
        commands = {'help': self.help(counter = counter),'current_time': self.current_time()} #add functions for commands in this dict, then add the function below as a def
        try:
            try:
                word_list = re.sub("[^\w]", " ",  self.command).split()
                commands[word_list[0]]
                return commands[word_list[0]] 
            except:
                commands[self.command]
                return commands[self.command]
        except:
            return None


##############################definitions of commands

    def help(self, counter):
        self.counter = counter
        num_of_rows = 2
        output = ""
        if (num_of_term_rows-self.counter)>num_of_rows:
            helped = 'Valid ? commands are: '
            for com in all_commands: 
                output = output + all_commands[com] + ", "

            helped = str(helped)+output
            helped = helped.rstrip(helped[-1])
            helped = helped.rstrip(helped[-1])
            num_of_rows = 1
  
        else:
            helped = "Not enough room in the termial to display this text! -> use command 'recycle' to clear the termial"
            num_of_rows = 1
        return helped, num_of_rows

###

    def current_time(self):

        num_of_rows = 1
        now = datetime.now()
        time = now.strftime("%H:%M:%S")
        return time,num_of_rows

###


##############################definitions of commands

###history command
def history(command, on_or_off, com_ouput):
    if on_or_off == True: 
        try:
            history_file = open("history_of_commands.txt", "a+")
            history_file.write(f"\n{command}\r")
            history_file.write(f"{com_ouput}\n")
            history_file.close()
        except: 
            history_file = open("history_of_commands.txt", "a+")
            history_file.write(f"\n{command}\r\n")
            history_file.close()
###history command

        
####code for tests
# command = Command()
# recognized_command = command.recog_command('help', 1)  