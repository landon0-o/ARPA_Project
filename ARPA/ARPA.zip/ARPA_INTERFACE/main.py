'''Things to include:
    write pump vals to config.json 
    write battery vals to config.json 
    write patient vals to config.json
    make data directory and include config.json and metadata.json
'''


import curses 
import time
from curses.textpad import Textbox, rectangle
from curses import wrapper

from commands.arpa_information import*
from commands.arpa_information import*

####globably used variables
counter = 1
max_command_length = 80
global com_output

####globably used variables




'''
Welcome to ARPA! This is a fully intergrated termial application for development and interface
with ARPA.

***Code written by Landon Flemming, last updated February 7th, 2022***
'''
#       ___           ___           ___           ___     
#      /\  \         /\  \         /\  \         /\  \    
#     /::\  \       /::\  \       /::\  \       /::\  \   
#    /:/\:\  \     /:/\:\  \     /:/\:\  \     /:/\:\  \  
#   /::\~\:\  \   /::\~\:\  \   /::\~\:\  \   /::\~\:\  \ 
#  /:/\:\ \:\__\ /:/\:\ \:\__\ /:/\:\ \:\__\ /:/\:\ \:\__\
#  \/__\:\/:/  / \/_|::\/:/  / \/__\:\/:/  / \/__\:\/:/  /
#       \::/  /     |:|::/  /       \::/  /       \::/  / 
#       /:/  /      |:|\/__/         \/__/        /:/  /  
#      /:/  /       |:|  |                       /:/  /   
#      \/__/         \|__|                       \/__/    


stdscr = curses.initscr()
def main(stdscr):
######################################################################welcome screen  
    curses.resize_term(30,120)
    curses.init_pair(1, curses.COLOR_BLUE, curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_CYAN, curses.COLOR_BLACK)
    curses.init_pair(3, curses.COLOR_MAGENTA, curses.COLOR_BLACK)
    curses.init_pair(4, curses.COLOR_YELLOW, curses.COLOR_BLACK)
    curses.init_pair(5, curses.COLOR_RED, curses.COLOR_BLACK)
    curses.init_pair(6, curses.COLOR_GREEN, curses.COLOR_BLACK)
    curses.init_pair(7, curses.COLOR_WHITE, curses.COLOR_CYAN)

    BLUE_BLACK = curses.color_pair(1) #ordered TEXTCOLOR_BACKGROUNDCOLOR
    CYAN_BLACK = curses.color_pair(2) #ordered TEXTCOLOR_BACKGROUNDCOLOR
    MAGENTA_BLACK = curses.color_pair(3) #ordered TEXTCOLOR_BACKGROUNDCOLOR
    YELLOW_BLACK = curses.color_pair(4) #ordered TEXTCOLOR_BACKGROUNDCOLOR
    RED_BLACK = curses.color_pair(5) #ordered TEXTCOLOR_BACKGROUNDCOLOR
    GREEN_BLACK = curses.color_pair(6) #ordered TEXTCOLOR_BACKGROUNDCOLOR
    WHITE_CYAN = curses.color_pair(7) #ordered TEXTCOLOR_BACKGROUNDCOLOR
    stdscr.attron(CYAN_BLACK)
    stdscr.clear()  
    stdscr.refresh()
    stdscr.addstr(0,32,"      ___           ___           ___           ___     ")  
    stdscr.addstr(1,32,"     /\  \         /\  \         /\  \         /\  \    ") 
    stdscr.addstr(2,32,"    /::\  \       /::\  \       /::\  \       /::\  \   ")
    stdscr.addstr(3,32,"   /:/\:\  \     /:/\:\  \     /:/\:\  \     /:/\:\  \  ") 
    stdscr.addstr(4,32,"  /::\~\:\  \   /::\~\:\  \   /::\~\:\  \   /::\~\:\  \ ")   
    stdscr.addstr(5,32, " /:/\:\ \:\__\ /:/\:\ \:\__\ /:/\:\ \:\__\ /:/\:\ \:\__\\")
    stdscr.addstr(6,32," \/__\:\/:/  / \/_|::\/:/  / \/__\:\/:/  / \/__\:\/:/  /")  
    stdscr.addstr(7,32,"      \::/  /     |:|::/  /       \::/  /       \::/  / ") 
    stdscr.addstr(8,32,"      /:/  /      |:|\/__/         \/__/        /:/  /  ") 
    stdscr.addstr(9,32,"     /:/  /       |:|  |                       /:/  /   ") 
    stdscr.addstr(10,32,"     \/__/         \|__|                       \/__/    ")   
    stdscr.attroff(CYAN_BLACK)
    stdscr.addstr(12,43, "ARTIFICIAL PANCREAS INTERFACE SOFTWARE", MAGENTA_BLACK)
    
    stdscr.addstr(14,52, "Welcome to ARPA!")
    stdscr.addstr(15,5, "Operators: ")
    stdscr.addstr(16,8, "? - use this operator to get information", YELLOW_BLACK)
    stdscr.addstr(17,8, "! - use this operator to access development tools", CYAN_BLACK)
    stdscr.addstr(18,8, "$ - use this operator to access direct interface commands", MAGENTA_BLACK)

    stdscr.addstr(15,65, "help commands:")
    stdscr.addstr(16,68, "?help", YELLOW_BLACK)
    stdscr.addstr(17,68, "!help", CYAN_BLACK)
    stdscr.addstr(18,68, "$help", MAGENTA_BLACK)
    stdscr.addstr(15,85, "General commands")
    stdscr.addstr(16,84, "quit", CYAN_BLACK)
    stdscr.addstr(17,84, "recycle", CYAN_BLACK)
    stdscr.addstr(18,84, "help", CYAN_BLACK)

    stdscr.addstr(16,93, "history_on", CYAN_BLACK)
    stdscr.addstr(17,93, "history_off", CYAN_BLACK)


    stdscr.addstr(27,36, "DON'T RESIZE THE TERMINAL ONCE YOU INPUT A COMMAND!", RED_BLACK)
    stdscr.addstr(28,29, "If the termial gets messed up, use command 'recycle' to reset it", RED_BLACK)
    stdscr.addstr(29,43, "you may need to do this a couple of times", RED_BLACK)
    
    stdscr.addstr(22,5, "Press Any Key to Begin!")
    rectangle(stdscr, 13,4,19,116)
    
    stdscr.getch()
######################################################################welcome screen
######################################################################termial screen
    stdscr.clear()
    stdscr.refresh()
    curses.resize_term(30, 120)
    counter = 0
    on_or_off = False
    while True: 
        try:
            stdscr.move(counter, 0)
            stdscr.addstr(">")
            command_win = curses.newwin(1, max_command_length, counter,1)
            stdscr.refresh()
            command_win.attron(CYAN_BLACK)
            curses.echo()
            command = str(command_win.getstr(), 'UTF-8')
            command_win.attroff(CYAN_BLACK)            
        except:
            stdscr.clear()
            command_win = curses.newwin(1, max_command_length, 0,1)
            stdscr.addstr(0,0,">")
            stdscr.refresh()
            counter = 0

        # command_line = Textbox(command_win)
        # stdscr.refresh()
        # command_line.edit()
        # command = command_line.gather()   
        

        ####builtin commands and operator differentiation
        if command == "quit":
            break
        elif command == "recycle":
            stdscr.clear()
            stdscr.refresh()
            counter = 0
            stdscr.addstr(0,0,">")
            stdscr.move(1, 0)
        elif command == "josh is a noob, right?":
            counter+=1
            stdscr.addstr(counter,0, "yes, correct as always landon")
            counter+=1
        elif command == "josh is a boob, right?":
            counter+=1
            stdscr.addstr(counter,0, "yes, correct as always landon")
            counter+=1
        elif command == "Sawyer sucks at valorant":
            counter+=1
            stdscr.addstr(counter,0, "yes, correct as always landon")
            counter+=1
        elif command == "help":
            counter+=1
            stdscr.addstr(counter,0, "Valid general commands are: quit, recycle, help, history_on, history_off")
            counter+=1
        elif command == "history_on":
            counter+=1
            stdscr.addstr(counter, 0, "History is On! All of your entered commands will be saved in a file named history_of_commands.txt")
            on_or_off = True
            counter+=1
        elif command == "history_off":
            counter+=1
            stdscr.addstr(counter, 0, "History is Off! All of your entered commands will no longer be saved in a file named history_of_commands.txt")
            on_or_off = False
            counter+=1
        elif command[0] == "?":
            command = command.replace("?", "")
            try:
                handled_command = Info_Command()
                output = handled_command.recog_command(command, counter)
                counter += 1
                stdscr.attron(YELLOW_BLACK)
                stdscr.addstr(counter, 0, str(output[0]))
                com_output = output[0]
                stdscr.attroff(YELLOW_BLACK)
                counter += output[1]
            except:
                stdscr.attron(RED_BLACK)
                counter+=1            
                stdscr.addstr((counter-1), 0, "? command not recognized. Use ?help to get a list of valid ? commands")
                
                stdscr.attroff(RED_BLACK)
        elif command[0] == "!":
            command = command.replace("!", "")
            try:
                handled_command = Dev_Command()
                output = handled_command.recog_command(command, counter)
                counter += 1
                stdscr.attron(MAGENTA_BLACK)
                stdscr.addstr(counter, 0, str(output[0]))
                com_output = output[0]
                stdscr.attroff(MAGENTA_BLACK)
                counter += output[1]
            except:
                stdscr.attron(RED_BLACK)
                counter+=1            
                stdscr.addstr((counter-1), 0, "! command not recognized. Use !help to get a list of valid ! commands")
                
                stdscr.attroff(RED_BLACK)
        elif command[0] == "$":
            command = command.replace("$", "")
            
        else:
            try:
                stdscr.attron(RED_BLACK)
                counter+=1            
                stdscr.addstr((counter), 0, "Command does not exist. Use the 'help' commands to get information on the ?, !, and $ operators")
                counter+=1
                stdscr.attroff(RED_BLACK)
            except:
                stdscr.clear()
                stdscr.refresh()
                counter = 0
                
                stdscr.addstr(0,0,">")
                stdscr.move(1, 0)
        try:
            history(command, on_or_off, com_output)
            com_output = "There was no output, or an error message was thrown"
        except:
            com_output = "There was no output, or an error message was thrown"
            history(command, on_or_off, com_output)
        ####builtin commands and operator differentiation
######################################################################termial screen

wrapper(main) 