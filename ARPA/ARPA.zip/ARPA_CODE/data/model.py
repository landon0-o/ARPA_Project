

weights = [

]

bias = [

]

