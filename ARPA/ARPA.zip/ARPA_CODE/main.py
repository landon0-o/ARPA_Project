#imports
import machine
import time
import neopixel
import json

#custom module imports
from libs.tfinterpreter import*
from components.pump import*
from components.battery import*

#global vars
loop_state = True

#loop
while loop_state:
    pass
