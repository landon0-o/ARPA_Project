import machine

class Battery:
    def __init__(self):
        pass
    def batt_health(self):
        pass
    def batt_cycles(self):
        pass
    def batt_level(self):
        pass
    def batt_nominal_discharge_rate(self, timeframe):
        pass