class Memory:
    def log_time(self, time):
        data['Pump']['retract_speed'] = 10+i
        a_file = open("ARPA_CODE/data/config.json", "w")
        time.sleep(1)
        json.dump(data, a_file, indent=2)
        print(data['Pump']['retract_speed'])
    def get_last_time(self):
        pass
    def log_dose(self, dose):
        pass