



# import serial
# import time
# arduino = serial.Serial(port='/dev/cu.usbserial-0001', baudrate=115200, timeout=.1)

# def write_read():
#     time.sleep(0.05)
#     data = arduino.readline()
#     if str(data) == "b''": pass
#     else: return str(data)

# while True:
#     data = write_read()
#     if data == None: pass
#     else: print(data)

# import json
# import os
# import time


# f = open("ARPA_CODE/data/config.json", "r")

# data = json.load(f)

# for i in range(0,10):
#     data['Pump']['retract_speed'] = 10+i
#     a_file = open("ARPA_CODE/data/config.json", "w")
#     time.sleep(1)
#     json.dump(data, a_file, indent=2)
#     print(data['Pump']['retract_speed'])
# f.close()
# a_file.close()

from components.pump import*

something = Pump()
something.dose(5)

